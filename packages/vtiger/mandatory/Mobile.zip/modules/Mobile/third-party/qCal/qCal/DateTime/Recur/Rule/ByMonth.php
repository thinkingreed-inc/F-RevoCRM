<?php
class qCal_DateTime_Recur_Rule_ByMonth extends qCal_DateTime_Recur_Rule {

	/**
	 * If there are sub-rules then this rule may return more than one instance or it
	 * may return none.
	 */
	public function getRecurrences() {
	
		return array();
	
	}

}