<?php
class qCal_Exception_FileNotFound extends qCal_Exception {

	// hooty

}